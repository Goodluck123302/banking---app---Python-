import random
from datetime import datetime as dt
import os
import json
class BankAccount():
    #add interest at the end of every month and keep track of interest added
    interest = 0.03
    @classmethod
    def set_interest(cls,interest):
        cls.interest = interest
    
    
    
    def __init__(self):
        self.__balance_file = 'balance_file.json'
        self.__statement_file = 'statement_file.txt'
        self.__account_file = 'account_file.json'
        self.__balance = {"amount": 0}
   
        
    def account_number(self):
        number = ""
        for i in range(10):
            number +=  str(random.choice(list(range(9))))
        return number 
    
    def create_account(self):
        
        self.name = input("Enter your full name: ").title()
        #update age yearly 
        while True:
            try:
                self.age = dt.now().year - int(input("Enter your birth year: "))
                while self.age < 0:
                    print(f"Your birth year can't be greater than current year ")
                    self.age = dt.now().year - int(input("Enter your birth year: "))
                    
   
                break 
            except ValueError:
                print("Please enter a digit") 
        self.next_of_kins = input("Enter your next of kins: ").title()
        self.residential_address = input("Enter your residential address: ").title()
        self.account_number_value = self.account_number()
        
        account_details = {"Name": self.name, "Age": self.age, "next of kins" : self.next_of_kins, "Residential address": self.residential_address, "Account number" : self.account_number_value} 
        
        self.save_file(self.__account_file, account_details)
    
    def account_exists(self, file):
        if os.path.getsize(self.__account_file) == 2:
                print("You don't have any account.\nPlease create an account")  
                return False
        return True
            #it was equated to 2 and not 0 because there is a dictionary('{}') written at the beginning before execution.
        
    
        
    def save_file(self, file, data):
        with open(file, "w") as a_file:
            json.dump(data, a_file)
            
        print("Saved successfully")
    
    def open_file(self, file):
            
        if not os.path.exists(file):
                return {}
        if os.path.getsize(file) == 0:
            return {}
                
        with open(file, "r") as a_file:
            
            try:
                return json.load(a_file)
            except json.JSONDecodeError:
                return {}

    def see_account_info(self):
            account_info = self.open_file(self.__account_file)
            if len(account_info) == 0:
                print("No Information stored. \nPlese create an account.")
                return 
            
            for i in account_info:
                print(f"{i} :  {account_info[i]}")
            
    def deposit(self):
            if not self.account_exists(self.__account_file):
                return 0
            
            data = self.open_file(self.__balance_file)
            if len(data) == 0:
                balance = 0
            else:
                balance = data['amount']
            while True:
               try:
                  deposit = float(input("Enter amount: "))
                  break 
               except ValueError:
                   print("Enter a digit")
                
            balance += deposit
            self.__balance['amount'] = balance  
            self.save_file(self.__balance_file, self.__balance)
            self.save_statement("deposited", deposit)

     
    def withdraw(self):
            if not self.account_exists(self.__account_file):
                return 0
            data = self.open_file(self.__balance_file)
            if len(data) == 0:
                balance = 0
            else:
                balance = data['amount']
            while True:
               try:
                  withdraw = float(input("Enter amount: "))
                  break 
               except ValueError:
                   print("Enter a digit")
                   
            if withdraw > balance:
                print(" insufficient funds")
                return  
            balance -= withdraw 
            self.__balance['amount'] = balance  
            self.save_file(self.__balance_file, self.__balance)
            self.save_statement("withdrew", withdraw)
            
    def check_balance(self):
        if not self.account_exists(self.__account_file):
                return 0
        data = self.open_file(self.__balance_file)
        
        if len(data) == 0:
            print("Your have $0 balance")
            return 
        else:
            balance = data['amount']
        print(f"Your balance is ${balance}")
    
    def save_statement(self, action, amount):
            time = dt.now().ctime()
            with open(self.__statement_file, 'a') as file:
                file.write(f"${amount} was {action}  on {time}\n")
    
    def view_statement(self):
            if not self.account_exists(self.__account_file):
                return 0
            with open(self.__statement_file) as file:
                data = file.read()
                if len(data) == 0:
                    print("Please create an account.")
                    return 
                print(data)
    
    def delete_account(self):
            files = [self.__balance_file, self.__account_file]
            for file in files:
                with open(file, "w") as a_file:
                    json.dump({}, a_file)
            with open(self.__statement_file, "w") as state_file:
                   state_file.write("")
            print("Account deleted ")
    
    @staticmethod
    def menu(account):
                   account  = BankAccount() 
                   while True:          
                       print("\n\nWelcome to our banking services\n1.\tCreate an Account \n2.\tSee account details\n3.\tDeposit to your account\n4.\tWithdraw\n5.\tCheck balance\n6.\tView transactions\n7.\tDelete account\n8.\tExit\n\n")
                       try:
                          choice = input('Enter your choice: ')
                   
                       except ValueError:
                           print('Enter a digit please')
                       if choice == '1':                             account.create_account()
                       elif choice == '2':
                               account.see_account_info()    
                   
                       elif choice == '3':
                               account.deposit()
                       elif choice == '4':
                               account.withdraw()
                       elif choice == '5':
                               account.check_balance()
                   
                       elif choice == '6':
                               account.view_statement()
                   
                       elif choice == '7':
                               account.delete_account()
                   
                       elif choice == '8':
                               break 
                       else:
                               print("Please choose from the options")
                           
        
BankAccount.menu("my_account")           
            